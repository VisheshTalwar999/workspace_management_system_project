<template>
  <router-view></router-view>
</template>

<script setup lang="ts">
</script>

<style scoped>
body {
  margin: 0px !important;
}
</style>