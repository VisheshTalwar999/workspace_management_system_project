package com.wms.mail;

public class MailConstants {
	final static public String EMAIL="Your Gmail ID";
	final static public String PASSWORD="Your Generated Password";

}
