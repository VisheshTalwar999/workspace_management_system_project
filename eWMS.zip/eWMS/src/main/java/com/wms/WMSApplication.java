package com.wms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WMSApplication {

	public static void main(String[] args) {
		SpringApplication.run(WMSApplication.class, args);
	}

}
