package com.wms.models;

public class SeatLocationDetailRequest {
	
	private SeatLocationDetail details;
    private int number;
    
	public SeatLocationDetail getDetails() {
		return details;
	}
	public void setDetails(SeatLocationDetail details) {
		this.details = details;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}

  

}
